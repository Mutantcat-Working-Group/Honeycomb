﻿# Honeycomb Signing Kit (1.1.20260711)

把这一套搬到任意一台 Windows 上都能恢复 `appHoneycomb.exe` 的代码签名。

## 目录结构

```
Honeycomb_SigningKit_1.1.20260711\
├── cert\
│   ├── Mutantcat.pfx         代码签名证书（含私钥）-- 密码见下
│   └── Mutantcat.cer         公开证书（DER）-- 发给最终用户安装
├── tools\                    Windows SDK 签名工具，独立 exe 不需要额外运行时
│   ├── signtool.exe
│   ├── makecert.exe
│   ├── pvk2pfx.exe
│   ├── cert2spc.exe
│   ├── certmgr.exe
│   ├── 仅签名（需要现成的证书）.cmd
│   └── 创建证书+签名.cmd
└── scripts\
    ├── package.cmd           编译 Release + windeployqt + 打包 zip
    ├── sign.cmd              签名 exe / 所有 DLL（已配好这个证书）
    └── make_cert.ps1         若证书丢失可用此脚本重新签发（同样 subject/SAN）
```

## 证书信息

| 字段 | 值 |
|------|---|
| Subject | `CN=Mutantcat, O=Mutantcat, E=feedback@mutantcat.org` |
| DNS SAN | `www.mutantcat.org.cn` |
| 算法 | RSA 2048 + SHA256 |
| Key Usage | DigitalSignature |
| Extended Key Usage | Code Signing (1.3.6.1.5.5.7.3.3) |
| 有效期 | 2026-01-01 → 2036-01-01 |
| Thumbprint | `29A8AEE848178E0EE9F32B33E40CA3C008DC7CDF` |
| **PFX 密码** | **`LINGSHI.15m`** |

## 在新电脑上恢复签名环境的步骤

### 1. 解压本 kit 到任意目录，例如 `D:\HoneycombSign\`

### 2. 把 cert 拷到固定位置（也可直接留在 kit 里，脚本里改路径即可）

```cmd
copy D:\HoneycombSign\cert\Mutantcat.pfx D:\Cert\
copy D:\HoneycombSign\cert\Mutantcat.cer D:\Cert\
```

> sign.cmd 默认从 `D:\Cert\` 读证书。如果你放在别处，改 sign.cmd 里的 `CERTDIR` 一行。

### 3. 把 tools 加到 PATH（可选）

```cmd
set PATH=D:\HoneycombSign\tools;%PATH%
```

> 也可以不改 PATH，sign.cmd 里用的是 `%~dp0` 的相对位置，搬到哪都能跑。

### 4. 验证证书能正常加载

```cmd
signtool.exe verify /pa D:\HoneycombSign\cert\Mutantcat.cer
```

### 5. 重新打签名包

```cmd
cd D:\HoneycombSign\scripts
package.cmd    :: 编译 Release + windeployqt + 打包（需要 VS2022 + Qt 6.10.1 + conan）
sign.cmd       :: 用本 kit 的证书签名 exe 和所有 DLL
```

### 6. 验证签名结果

```cmd
signtool.exe verify /pa appHoneycomb.exe
```

期望输出：`Successfully verified: appHoneycomb.exe`，Algorithm = sha256，Timestamp = RFC3161。

## 证书丢失怎么办？

如果 `Mutantcat.pfx` 丢了但 `Mutantcat.cer` 还在：

- 公钥可以重新分发
- 但**私钥丢了就再也签不出和原 exe 同一指纹的签名了**
- 此时只能跑 `scripts\make_cert.ps1` 重新生成自签名证书，subject/SAN 不变，但 thumbprint 会变 → 老的已经分发的 exe 会从「Verified」变成「Unknown publisher」

所以**必须把 PFX 多备份几份**（加密 U 盘 / 内部 Git 仓 / 密码管理器等）。PFX 本身有密码保护，相对安全。

## 用户侧证书安装

最终用户拿到 `Honeycomb_1.1.20260711_msvc2022_64.zip` 后：

1. 解压到任意目录
2. 双击 `Mutantcat_CodeSign.cer` → 安装证书 → 受信任的根证书颁发机构
3. 启动 `appHoneycomb.exe`，Windows 属性页会显示「已验证的发布者: Mutantcat」

## 注意事项

- 自签名证书不会让 SmartScreen 的「未知发布者」首次警告消失（那需要 EV 代码签名证书）。但安装上面那一步后，UAC 弹窗和文件属性里都能正确显示「Mutantcat」。
- 时间戳服务器：`http://timestamp.sectigo.com`（RFC3161），证书过期后签名仍可验证。