﻿$ErrorActionPreference = 'Stop'
$pwd = ConvertTo-SecureString 'LINGSHI.15m' -Force -AsPlainText
$subj = 'CN=Mutantcat, O=Mutantcat, E=feedback@mutantcat.org'
$dns  = 'www.mutantcat.org.cn'
Write-Host "Creating self-signed cert: $subj"
Write-Host "  DNS SAN:               $dns"
$cert = New-SelfSignedCertificate `
    -Subject $subj `
    -DnsName $dns `
    -CertStoreLocation 'Cert:\CurrentUser\My' `
    -KeyAlgorithm RSA `
    -KeyLength 2048 `
    -NotAfter (Get-Date).AddYears(10) `
    -KeyUsage DigitalSignature `
    -Type CodeSigningCert
Write-Host "  Thumbprint: $($cert.Thumbprint)"
Write-Host "  NotAfter:   $($cert.NotAfter)"
Export-PfxCertificate -Cert $cert -FilePath 'D:\Cert\Mutantcat.pfx' -Password $pwd | Out-Null
Export-Certificate  -Cert $cert -FilePath 'D:\Cert\Mutantcat.cer'            | Out-Null
Write-Host 'Wrote D:\Cert\Mutantcat.pfx and D:\Cert\Mutantcat.cer'