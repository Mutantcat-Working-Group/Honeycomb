@echo off
setlocal EnableExtensions
setlocal EnableDelayedExpansion

set "SIGNTOOL=D:\Softwares\Win签名工具"
set "CERTDIR=D:\Cert"
set "STAGE=E:\Projects\Honeycomb_1.1.20260711_msvc2022_64"
set "OUTZIP=E:\Projects\Honeycomb_1.1.20260711_msvc2022_64.zip"
set "PFX=%CERTDIR%\Mutantcat.pfx"
set "CER=%CERTDIR%\Mutantcat.cer"
set "PWD=LINGSHI.15m"
set "TSURL=http://timestamp.sectigo.com"

echo === [0/8] create self-signed cert ===
if not exist "%PFX%" (
    powershell -NoProfile -ExecutionPolicy Bypass -File "D:\Cert\make_cert.ps1"
    if errorlevel 1 exit /b 1
    echo   (cert + PFX written to D:\Cert\)
) else (
    echo   (using existing PFX)
)

echo === [1/8] sign appHoneycomb.exe ===
"%SIGNTOOL%\signtool.exe" sign /f "%PFX%" /p "%PWD%" /fd SHA256 /tr %TSURL% /td SHA256 "%STAGE%\appHoneycomb.exe"
if errorlevel 1 exit /b 1

echo === [2/8] sign all *.dll in stage ===
set "CNT=0"
set "ERR=0"
for /R "%STAGE%" %%F in (*.dll) do (
    "%SIGNTOOL%\signtool.exe" sign /f "%PFX%" /p "%PWD%" /fd SHA256 /tr %TSURL% /td SHA256 "%%F" >nul 2>&1
    if not errorlevel 1 (set /a CNT+=1) else (set /a ERR+=1)
)
echo   signed: !CNT!   failed: !ERR!

echo === [3/8] sign *.dll under platforms ===
for /R "%STAGE%\platforms" %%F in (*.dll) do (
    "%SIGNTOOL%\signtool.exe" sign /f "%PFX%" /p "%PWD%" /fd SHA256 /tr %TSURL% /td SHA256 "%%F" >nul 2>&1
)

echo === [4/8] sign *.dll under qml ===
for /R "%STAGE%\qml" %%F in (*.dll) do (
    "%SIGNTOOL%\signtool.exe" sign /f "%PFX%" /p "%PWD%" /fd SHA256 /tr %TSURL% /td SHA256 "%%F" >nul 2>&1
)

echo === [5/8] verify appHoneycomb.exe signature ===
"%SIGNTOOL%\signtool.exe" verify /pa "%STAGE%\appHoneycomb.exe"

echo === [6/8] zip + try sign the zip ===
powershell -NoProfile -Command "Compress-Archive -Path '%STAGE%\*' -DestinationPath '%OUTZIP%' -Force"
"%SIGNTOOL%\signtool.exe" sign /f "%PFX%" /p "%PWD%" /fd SHA256 /tr %TSURL% /td SHA256 "%OUTZIP%"
if errorlevel 1 (
    echo   signtool rejected zip - falling back to SHA256 manifest
    powershell -NoProfile -Command "$h = Get-FileHash -Path '%OUTZIP%' -Algorithm SHA256; Set-Content -Path '%OUTZIP%.sha256.txt' -Value ($h.Hash.ToLower() + '  ' + (Get-Item '%OUTZIP%').Name) -Encoding utf8"
) else (
    echo   zip signed OK
)

echo === [7/8] ship cert alongside the zip ===
copy /Y "%CER%" "E:\Projects\Mutantcat_CodeSign.cer" >nul

echo === [8/8] done ===
exit /b 0
