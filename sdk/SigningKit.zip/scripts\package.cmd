@echo off
setlocal EnableExtensions EnableDelayedExpansion

set "ROOT=E:\Projects\Honeycomb"
set "BUILD=E:\Projects\honeycomb_build_release"
set "STAGE=E:\Projects\Honeycomb_1.1.20260711_msvc2022_64"
set "QT=D:\Softwares\Qt\6.10.1\msvc2022_64"
set "QTBIN=D:\Softwares\Qt\6.10.1\msvc2022_64\bin"
set "QTCMAKE=D:\Softwares\Qt\Tools\CMake_64\bin\cmake.exe"
set "VSBAT=D:\Softwares\Microsoft Visual Studio\2022\Professional\VC\Auxiliary\Build\vcvarsall.bat"

echo === [0/5] prepare ===
if exist "%BUILD%" rmdir /s /q "%BUILD%"
if exist "%STAGE%" rmdir /s /q "%STAGE%"
mkdir "%BUILD%"
mkdir "%STAGE%"

echo === [1/5] MSVC + conan install ===
call "%VSBAT%" x64
if errorlevel 1 (echo VCVARS_FAILED & exit /b 1)
set "PATH=%QTBIN%;D:\Softwares\Qt\Tools\CMake_64\bin;%PATH%"
cd /d "%BUILD%"

conan install "%ROOT%" --profile="%ROOT%\conan_profile_msvc_utf8" --build=missing -s compiler.cppstd=17 -of .
if errorlevel 1 exit /b 1

echo === [1b/5] patch conan toolchain: strip CMAKE_GENERATOR_PLATFORM/TOOLSET for Ninja ===
powershell -NoProfile -Command "(Get-Content '%BUILD%\conan_toolchain.cmake') -replace 'set\(CMAKE_GENERATOR_PLATFORM .*\)','set(CMAKE_GENERATOR_PLATFORM \"\" CACHE STRING \"\" FORCE)' -replace 'set\(CMAKE_GENERATOR_TOOLSET .*\)','set(CMAKE_GENERATOR_TOOLSET \"\" CACHE STRING \"\" FORCE)' | Set-Content '%BUILD%\conan_toolchain.cmake'"

echo === [2/5] cmake configure (Ninja + Release + x64) ===
"%QTCMAKE%" -G Ninja -DCMAKE_BUILD_TYPE=Release "-DCMAKE_PREFIX_PATH=%QT%" "-DCMAKE_TOOLCHAIN_FILE=%BUILD%\conan_toolchain.cmake" "%ROOT%"
if errorlevel 1 exit /b 1

echo === [3/5] build Release ===
"%QTCMAKE%" --build "%BUILD%" --config Release --parallel
if errorlevel 1 exit /b 1

if not exist "%BUILD%\appHoneycomb.exe" (
    echo BUILD_OK_BUT_NO_EXE
    exit /b 1
)

echo === [4/5] stage files + windeployqt ===
copy /Y "%BUILD%\appHoneycomb.exe" "%STAGE%\" >nul
copy /Y "%ROOT%\logo.ico"   "%STAGE%\" >nul
copy /Y "%ROOT%\logo.png"   "%STAGE%\" >nul
copy /Y "%ROOT%\LICENSE.txt" "%STAGE%\" >nul
copy /Y "%ROOT%\README.md"  "%STAGE%\README.md" >nul
xcopy /Y /E /I /Q "%ROOT%\i18n"   "%STAGE%\i18n"   >nul
xcopy /Y /E /I /Q "%ROOT%\assets" "%STAGE%\assets" >nul

"%QTBIN%\windeployqt6.exe" --release --qmldir "%ROOT%" --no-system-d3d-compiler --no-opengl-sw "%STAGE%\appHoneycomb.exe"
if errorlevel 1 exit /b 1

echo === [5/5] zip ===
powershell -NoProfile -Command "Compress-Archive -Path '%STAGE%\*' -DestinationPath 'E:\Projects\Honeycomb_1.1.20260711_msvc2022_64.zip' -Force"
if errorlevel 1 exit /b 1

echo === DONE ===
exit /b 0